package com.wissensalt.test.sar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAngularRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAngularRegistrationApplication.class, args);
	}

}
