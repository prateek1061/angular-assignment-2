import { RequestLogin } from './request-login';

describe('RequestLogin', () => {
  it('should create an instance', () => {
    expect(new RequestLogin()).toBeTruthy();
  });
});
