export class ResponseError {
    timestamp : Date;
    status : number;
    exception : string;
    message : string;
    path : string;
    error : string;
}
