package dev.danvega.runnerz.run;

import java.util.List;

public record Runs(List<Run> runs) {
}
